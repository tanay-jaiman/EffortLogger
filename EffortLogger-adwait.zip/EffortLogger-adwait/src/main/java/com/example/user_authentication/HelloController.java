import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Scene;
import javafx.scene.control.Label;
import javafx.scene.control.PasswordField;
import javafx.scene.control.TextField;
import javafx.stage.Stage;
import javafx.stage.Window;

import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

public class HelloController {
    private static final String JDBC_URL = "jdbc:sqlite:/path/to/effortlogger.db";

    @FXML
    private Label authentication_text;
    @FXML
    private TextField username_input;
    @FXML
    private PasswordField password_input;

    @FXML
    protected void authentication_passed(Stage stage) throws IOException {
        FXMLLoader fxmlLoader = new FXMLLoader(HelloApplication.class.getResource("PlanningPoker.fxml"));
        Scene scene = new Scene(fxmlLoader.load(), 600, 600);
        stage.setTitle("Planning Poker");
        stage.setScene(scene);
        stage.show();
    }

    @FXML
    protected void onSubmitButtonClick() {
        String username = username_input.getText();
        String password = password_input.getText();

        try (Connection connection = DriverManager.getConnection(JDBC_URL)) {
            String query = "SELECT * FROM users WHERE username = ? AND password = ?";
            try (PreparedStatement preparedStatement = connection.prepareStatement(query)) {
                preparedStatement.setString(1, username);
                preparedStatement.setString(2, password);

                try (ResultSet resultSet = preparedStatement.executeQuery()) {
                    if (resultSet.next()) {
                        authentication_text.setText("Authentication Successful!");

                        try {
                            Window window = authentication_text.getScene().getWindow();
                            window.hide();
                            authentication_passed(new Stage());
                        } catch (Exception e) {
                            authentication_text.setText("An unexpected error occurred!");
                        }
                    } else {
                        authentication_text.setText("Authentication Failed! Try again.");
                        username_input.setText("");
                        password_input.setText("");
                    }
                }
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }
}
